<!DOCTYPE HTML>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<title>Jogathon 2011</title>
<link rel="stylesheet" type="text/css" href="style.css" media="all" />
<link rel="stylesheet" type="text/css" href="colors/blue.css" media="all" />
<link rel="stylesheet" type="text/css" href="js/prettyPhoto.css" media="all" />
<!--[if IE 7]>
	<link rel="stylesheet" type="text/css" href="ie.css" media="all" />
<![endif]-->
<script type="text/javascript" src="js/jquery-1.4.4.min.js"></script>
<script type="text/javascript" src="js/jquery.cycle.min.js"></script>
<script type="text/javascript" src="js/jquery.jcarousel.min.js"></script>
<script type="text/javascript" src="js/jquery.prettyPhoto.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	var invalidMailError	= "E-mail is not valid.";
	var duplicateMailError	= "E-mail is already in the list.";
	var systemError			= "An error occurred. Please try again.";
	var successMessage		= "Your e-mail is added to the list.";

	$(".resultText").hide();
	$(".loader").hide();
	
    $('form#newsletterForm').bind('submit', function(e){
		$(".resultText").hide();
		$(".loader").show();
		var email  = $('input#email').val();
        e.preventDefault();
		
		$.ajax({
			type: 'POST',
			url: 'newsletter.php?email='+email,
			data: '',
			success: function(theResponse){
				$(".resultText").fadeIn("slow");
				$(".resultText").animate({opacity: 1.0}, 3000);
				$(".resultText").fadeOut(1500);
				
				if (theResponse == 1) {
					$(".resultText").html(successMessage);
				}
				if (theResponse == 2) {
					$(".resultText").html(invalidMailError);
				}
				if (theResponse == 3) {
					$(".resultText").html(duplicateMailError);
				}
				$(".loader").hide();
			},
			error: function(){
				$(".resultText").html(systemError);
				$(".loader").hide();
			}		
		});
	});
			
});
</script>
</head>
<body>
<!-- Header Wrapper -->
<div id="header-wrapper"> 
  <!-- Header -->
  <div id="header"> 
    <!-- Header Top -->
    <div class="header-top"> 
      <!-- Logo -->
      <div class="logo"><!-- <a href="#" title=""><img src="images/logo.png" alt="MeegoFurn." /></a>--><h2> Jog-A-Thon</h2> </div>
      <!-- End Logo --> 
      
      <!-- Contact Us -->
      <div class="contactus"><span>Contact Us:</span> (630) 699-8503</div>
      <!-- End Contact Us --> 
    </div>
    <!-- End Header Top --> 
    
    <!-- Slideshow -->
    <div class="slideshow"> 
      <? 
      	$imgarray = array("kidpop.jpeg", "3kids.jpeg", "stretch2.jpeg", "liningup.jpeg", "kidwithdog.jpeg");
      
	  	foreach($imgarray as $val){
	  		
	  	
      ?>
      <!-- Slide -->
      <div class="slide">
        <div class="media"><img src="images/<?=$val?>" alt="Humboldt Community Christian School Image" /></div>
        <div class="text">
          <h2>HCCS Parents:</h2>
          <p>We are doing it again! Jogathon 2011 is scheduled for this September, and we want you to be involved. This is a great opportunity to help our school get the tools it needs to keep providing a high quality, affordable education in a personalized environment.</p>
          <p>&nbsp;</p>
          <h2>Make a pledge today by donating:</h2>
          <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
          	<input type="hidden" name="cmd" value="_donations">
          	<input type="hidden" name="business" value="humboldtchristianschool@comcast.net">
          	<input type="hidden" name="lc" value="US"><input type="hidden" name="item_name" value="Humboldt Community Christian School">
          	<input type="hidden" name="no_note" value="0"><input type="hidden" name="currency_code" value="USD">
          	<input type="hidden" name="bn" value="PP-DonationsBF:btn_donateCC_LG.gif:NonHostedGuest">
          	<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
          	<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
          	</form>


          </div>
      </div>
      <!-- End Slide --> 
      
      
      <? } ?>
     
    </div>
    <!-- End Slideshow --> 
    
    <!-- Slideshow Navigation -->
    <ul id="nav"></ul>
    <!-- End Slideshow Navigation --> 
    
  </div>
  <!-- End Header --> 
</div>
<!-- End Header Wrapper --> 

<!-- Middle -->
<div id="middle-wrapper">
  <div class="intro">
  	<article>
  	Please contact Marques Woodson if you would like to volunteer in any way :)
  	
  	<p><a href="mailto:marques.woodson@gmail.com">marques.woodson@gmail.com</a>
  	</p>
  	
  	<p>
  		Phone: 	630-699-8503
  	</p>
  
  	</article>
  </div>
  	
</div>
<!-- End Middle --> 

<!-- Container -->
<div id="container"> 
  
  <!-- Intro -->
  <div class="intro" align="center">
  		The Jog-A-Thon is coming Saturday, September 24th--  We hope you will join us!
  </div>
  <!-- End Intro --> 
  
  <!-- Left Content -->
  <div id="content"> 
    
    <!-- Top 2 Columns -->
    <div class="one-half">
      <h3><img src="images/s1.png" alt="" /> What do you do at a Jogathon?:</h3>
<ul><li>Walk or jog with our students.</li>
<li>Meet the teachers.</li>
<li>Tour the school.</li>
<li>Enjoy music and yummy Puerto Rican food.</li></ul>
    </div>
    <div class="one-half last">
      <h3><img src="images/s2.png" alt="" />  Getting Involved is Easy. You can:</h3>
<ul><li>Sponsor a class or a child.</li>
<li>Raise pledges.</li>
</ul>
    </div>
    <div class="clear"></div><br /><br /><br />
    <!-- End Top 2 Columns --> 
    
    <!-- Bottom 2 Columns -->
    <div class="one-half">
      <h3><img src="images/s3.png" alt="" />  Areas to serve (We need your help to make this
event a success):</h3>
<ul><li>Food - transporting, setting up, and serving</li>
<li>Set Up - marking off course, tables and chairs</li>
<li>Promotion and Prizes -helping contact businesses to support financially or
donate prizes</li>
<li>Set Up - marking off course, tables and chairs</li>
<li>Course Coaches - guiding participants around the course, counting laps</li>
</ul>
    </div>
    <div class="one-half last">
      <h3><img src="images/s4.png" alt="" /> Donate by PayPal</h3>
      <p> <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
          	<input type="hidden" name="cmd" value="_donations">
          	<input type="hidden" name="business" value="humboldtchristianschool@comcast.net">
          	<input type="hidden" name="lc" value="US"><input type="hidden" name="item_name" value="Humboldt Community Christian School">
          	<input type="hidden" name="no_note" value="0"><input type="hidden" name="currency_code" value="USD">
          	<input type="hidden" name="bn" value="PP-DonationsBF:btn_donateCC_LG.gif:NonHostedGuest">
          	<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
          	<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
          	</form></p>
    </div>
    <div class="clear"></div><br /><br /><br />
    <!-- End Bottom 2 Columns --> 
  </div>
  <!-- End Left Content --> 
  
  <!-- Right Side -->
  <div id="side"> 
    
   
    
    <!-- Testimonials -->
    <div id="testimonials-wrapper">
      <h3>Thanks for Participating!</h3>
      <div class="testimonials"> 
        
        <!-- Message -->
        <div class="message">
          <p>I will contact volunteers soon about assignments, and each parent will be given service hours for their contributions. The Jogathon will be held on Saturday, September 24th. I will provide more specifics
shortly. <br> Thanks so much. Together, we will make this a success!
 </p>
          <strong>--Marques Woodson</strong> </div>
        <!-- End Message --> 
        
        <!-- Message 
        <div class="message">
          <p>Morbi est elit, imperdiet sit amet pharetra eget, egestas in leo. Ut quis risus elit. Nunc semper aliquet nisl ut iaculis. Vivamus tristique odio et dui convallis dapibus ornare diam mattis. Proin non commodo elit.</p>
          <strong>by Charlene</strong> </div>
        <!-- End Message --> 
        
        <!-- Message 
        <div class="message">
          <p>Praesent sollicitudin ligula at diam iaculis auctor. Suspendisse tellus mi, condimentum id rutrum auctor, lobortis tempus orci. Nunc sem nisl, varius imperdiet mollis nec, molestie a quam. </p>
          <strong>by Mathieu</strong> </div>
        <!-- End Message --> 
        
      </div>
    </div>
    <!-- End Testimonials --> 
  </div>
  <!-- End Right Side -->
  
  <div class="clear"></div>
</div>
<!-- End Container -->

<!-- Begin Footer -->
<div id="footer-wrapper">
  <div id="footer">
    <p>© Copyright 2011 Jog-A-Thon. All Rights Reserved.</p>
    
  </div>
</div>
<!-- End Footer -->
</body>
</html>